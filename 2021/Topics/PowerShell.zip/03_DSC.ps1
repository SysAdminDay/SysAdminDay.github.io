﻿#Declare variable

$resourceGroup = "SysAdmin-Demo"
$location = "southeastasia"
$ComputerNameList = "SRV01","SRV02","SRV03"
$AutomationAccountName = "sysadmindemo"
$ConfigurationName = 'SysAdminConfig'

#Select Azure Subscription
Select-AzSubscription -SubscriptionId 00bf25a2-e3bb-4715-8153-18b6e95c38d4

get-AzAutomationDscConfiguration -ResourceGroupName $resourceGroup -AutomationAccountName $AutomationAccountName -Published
get-AzAutomationDscCompilationJob -ConfigurationName $ConfigurationName -ResourceGroupName $resourceGroup -AutomationAccountName $AutomationAccountName

Import-AzAutomationDscConfiguration -SourcePath '.\SysAdminConfig.ps1' -ResourceGroupName $resourceGroup -AutomationAccountName $AutomationAccountName -Published
Start-AzAutomationDscCompilationJob -ConfigurationName $ConfigurationName -ResourceGroupName $resourceGroup -AutomationAccountName $AutomationAccountName



ForEach ($name in $ComputerNameList)
{

 Write-host $name

# Run a DSC check every 60 minutes
# Register-AzAutomationDscNode -ResourceGroupName $resourceGroup -AutomationAccountName $AutomationAccountName -AzureVMName $name -ConfigurationModeFrequencyMins 60

 # Get the ID of the DSC node
$node = Get-AzAutomationDscNode -ResourceGroupName $resourceGroup -AutomationAccountName $AutomationAccountName -Name $name

# Assign the node configuration to the DSC node
Set-AzAutomationDscNode -ResourceGroupName $resourceGroup -AutomationAccountName $AutomationAccountName -NodeConfigurationName 'SysAdminConfig.WebServer' -NodeId $node.Id -Force


}


Get-AzAutomationDscNode -ResourceGroupName $resourceGroup -AutomationAccountName $AutomationAccountName | ft name,status


#Check the compliance status of a managed node
ForEach ($name in $ComputerNameList)
{
    Write-host $name
    # Get the ID of the DSC node
    $node = Get-AzAutomationDscNode -ResourceGroupName $resourceGroup -AutomationAccountName $AutomationAccountName -Name $name

    # Get an array of status reports for the DSC node
    $reports = Get-AzAutomationDscNodeReport -ResourceGroupName $resourceGroup -AutomationAccountName $AutomationAccountName -NodeId $node.Id -latest

    # Display the most recent report
    $reports[0]
}