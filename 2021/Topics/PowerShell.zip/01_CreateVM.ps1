﻿#Declare variable

$resourceGroup = "SysAdmin-Demo"
$location = "southeastasia"

#Virtual Network Configuration
$vnetName = "VNET-SysAdmin-Demo"
$VnetAddressPrefix = "192.168.0.0/16"
$subnetname = "Subnet-Web"
$SubnetAddressPrefix = "192.168.1.0/24"
$VMSize = "Standard_DS3"

#VMinformation
$ComputerNameList = "SRV01","SRV02","SRV03"
#$VMNamePrefix = "Web-"
$pipNamePrefix = "pip-"
$nsgNamePrefix = "nsg-"
$NICNamePrefix = "nic-"


#Prepare credential for local admin
$securePassword = ConvertTo-SecureString 'Pa55w.rd' -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential ("azureuser", $securePassword)

#Select Azure Subscription
Select-AzSubscription -SubscriptionId 00bf25a2-e3bb-4715-8153-18b6e95c38d4


#Create Azure Virtual Network
$Subnet = New-AzVirtualNetworkSubnetConfig -Name $subnetname -AddressPrefix $SubnetAddressPrefix
$Vnet = New-AzVirtualNetwork -Name $vnetName -ResourceGroupName $resourceGroup -Location $location -AddressPrefix $VnetAddressPrefix -Subnet $Subnet



ForEach ($name in $ComputerNameList)
{
   $ComputerName = $name
   $VMName = $name
   $pipName = "pip-"+$name+$(Get-Random)
   $nsgName = "nsg-"+$name
   $NICName = "nic-"+$name

   Write-host $ComputerName

   $pip = New-AzPublicIpAddress -ResourceGroupName $resourceGroup -Location $location  -Name $pipName -AllocationMethod Static -IdleTimeoutInMinutes 4

   $NIC = New-AzNetworkInterface -Name $NICName -ResourceGroupName $resourceGroup -Location $location -SubnetId $Vnet.Subnets[0].Id -PublicIpAddressId $pip.Id


   $VirtualMachine = New-AzVMConfig -VMName $VMName -VMSize $VMSize
   $VirtualMachine = Set-AzVMOperatingSystem -VM $VirtualMachine -Windows -ComputerName $ComputerName -Credential $Cred -ProvisionVMAgent -EnableAutoUpdate
   $VirtualMachine = Add-AzVMNetworkInterface -VM $VirtualMachine -Id $NIC.Id
   $VirtualMachine = Set-AzVMSourceImage -VM $VirtualMachine -PublisherName 'MicrosoftWindowsServer' -Offer 'WindowsServer' -Skus '2012-R2-Datacenter' -Version latest

   New-AzVM -ResourceGroupName $resourceGroup -Location $location -VM $VirtualMachine -Verbose


}




